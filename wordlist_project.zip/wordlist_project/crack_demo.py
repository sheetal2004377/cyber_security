#!/usr/bin/env python3
"""
Dictionary Attack Demo — tests a generated wordlist against sample hashes.

Reads hashes from sample_hashes.txt in the format "algorithm:hexdigest"
(one per line, algorithm in {md5, sha1, sha256}), hashes every candidate
from wordlist.txt with the matching algorithm, and reports which hashes
were cracked, with which password, and how long it took.

Usage:
    python3 crack_demo.py
    python3 crack_demo.py --wordlist wordlist.txt --hashes sample_hashes.txt
"""

import argparse
import hashlib
import time
from pathlib import Path

HASHERS = {
    "md5": hashlib.md5,
    "sha1": hashlib.sha1,
    "sha256": hashlib.sha256,
}


def load_hashes(path):
    targets = []
    with open(path, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or ":" not in line:
                continue
            algo, digest = line.split(":", 1)
            algo = algo.strip().lower()
            digest = digest.strip().lower()
            if algo in HASHERS:
                targets.append((algo, digest))
    return targets


def load_wordlist(path):
    with open(path, "r", encoding="utf-8") as fh:
        return [line.rstrip("\n") for line in fh if line.strip()]


def crack(wordlist, targets):
    # Group remaining (uncracked) targets by algorithm for efficient lookup
    remaining = {algo: set() for algo in HASHERS}
    for algo, digest in targets:
        remaining[algo].add(digest)

    found = {}  # (algo, digest) -> password
    start = time.time()
    attempts = 0

    for word in wordlist:
        for algo, digests in remaining.items():
            if not digests:
                continue
            attempts += 1
            h = HASHERS[algo](word.encode()).hexdigest()
            if h in digests:
                found[(algo, h)] = word
                digests.discard(h)
        if all(not d for d in remaining.values()):
            break  # everything cracked, stop early

    elapsed = time.time() - start
    return found, attempts, elapsed


def main():
    parser = argparse.ArgumentParser(description="Dictionary attack demo against sample hashes.")
    parser.add_argument("--wordlist", "-w", default="wordlist.txt")
    parser.add_argument("--hashes", "-H", default="sample_hashes.txt")
    args = parser.parse_args()

    wl_path, hash_path = Path(args.wordlist), Path(args.hashes)
    if not wl_path.exists():
        print(f"[!] Wordlist not found: {wl_path}. Run wordlist_generator.py first.")
        return
    if not hash_path.exists():
        print(f"[!] Hash file not found: {hash_path}. Run make_sample_hashes.py first.")
        return

    wordlist = load_wordlist(wl_path)
    targets = load_hashes(hash_path)

    print(f"[*] Loaded {len(wordlist)} candidate passwords from {wl_path}")
    print(f"[*] Loaded {len(targets)} target hashes from {hash_path}")
    print("[*] Starting dictionary attack...\n")

    found, attempts, elapsed = crack(wordlist, targets)

    cracked_set = {d for _, d in found}
    print("=" * 60)
    for algo, digest in targets:
        if digest in cracked_set and (algo, digest) in found:
            print(f"  [CRACKED]  {algo}:{digest}  ->  password = '{found[(algo, digest)]}'")
        else:
            print(f"  [FAILED ]  {algo}:{digest}  ->  not found in wordlist")
    print("=" * 60)
    n_cracked = len(found)
    print(f"\nSummary: {n_cracked}/{len(targets)} hashes cracked")
    print(f"Hash attempts : {attempts}")
    print(f"Time elapsed  : {elapsed:.4f} seconds")
    if elapsed > 0:
        print(f"Speed         : {attempts/elapsed:,.0f} hashes/sec")


if __name__ == "__main__":
    main()
