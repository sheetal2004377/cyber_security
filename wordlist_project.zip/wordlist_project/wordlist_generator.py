#!/usr/bin/env python3
"""
Custom Wordlist Generator with Mangling Rules (CUPP-like)
-----------------------------------------------------------
Cyber Security Lab — Exp 3: Dictionary & Brute Force Attack

Generates a targeted password wordlist from personal profile hints
(name, nickname, partner, pet, birthdate, etc.) and applies common
password-mangling rules (leetspeak substitution, case variants,
suffix/prefix appends, year ranges) — the same approach used by
tools like CUPP (Common User Passwords Profiler).

Usage:
    python3 wordlist_generator.py
    python3 wordlist_generator.py --interactive
    python3 wordlist_generator.py --config profile.json -o wordlist.txt

Author: for academic use (Cyber Security Lab)
"""

import argparse
import itertools
import json
import sys
from pathlib import Path

# --------------------------------------------------------------------------
# 1. Leetspeak substitution table
# --------------------------------------------------------------------------
LEET_MAP = {
    "a": ["a", "4", "@"],
    "b": ["b", "8"],
    "e": ["e", "3"],
    "i": ["i", "1", "!"],
    "o": ["o", "0"],
    "s": ["s", "5", "$"],
    "t": ["t", "7"],
    "g": ["g", "9"],
    "l": ["l", "1"],
}

# Common suffixes appended to base words (years, special chars, digits)
DEFAULT_YEAR_RANGE = range(1980, 2027)          # birth-year-ish range
COMMON_SUFFIXES = ["!", "@", "#", "123", "1", "007", "321", "99"]
COMMON_PREFIXES = ["", "I", "my", "the"]


def leetspeak_variants(word, max_variants=8):
    """
    Generate a bounded set of leetspeak variants for a word.
    Doing a full cartesian product of every substitutable letter explodes
    combinatorially, so we cap the number of substituted positions and
    the number of variants returned.
    """
    word = word.lower()
    positions = [i for i, ch in enumerate(word) if ch in LEET_MAP]
    if not positions:
        return {word}

    variants = {word}
    # Limit how many letter-positions we mutate at once to keep this sane
    for r in range(1, min(3, len(positions)) + 1):
        for combo in itertools.combinations(positions, r):
            choices = [LEET_MAP[word[i]] for i in combo]
            for repl in itertools.product(*choices):
                chars = list(word)
                for pos, new_char in zip(combo, repl):
                    chars[pos] = new_char
                variants.add("".join(chars))
                if len(variants) >= max_variants:
                    return variants
    return variants


def case_variants(word):
    """lowercase, UPPERCASE, Capitalized, and tOGGLEcASE."""
    out = {word.lower(), word.upper(), word.capitalize()}
    toggled = "".join(c.upper() if c.islower() else c.lower() for c in word)
    out.add(toggled)
    return out


def date_tokens(dob):
    """
    Turn a date-of-birth string (DD-MM-YYYY, DD/MM/YYYY, or YYYY) into
    useful numeric tokens: full year, 2-digit year, DDMM, MMDD, DDMMYYYY.
    """
    tokens = set()
    if not dob:
        return tokens
    sep = "-" if "-" in dob else "/" if "/" in dob else None
    parts = dob.split(sep) if sep else [dob]

    if len(parts) == 3:
        dd, mm, yyyy = parts
        tokens.update({yyyy, yyyy[-2:], dd + mm, mm + dd, dd + mm + yyyy, yyyy + mm + dd})
    elif len(parts) == 1 and parts[0].isdigit() and len(parts[0]) == 4:
        yyyy = parts[0]
        tokens.update({yyyy, yyyy[-2:]})
    return tokens


def build_base_words(profile):
    """Collect every raw keyword from the profile dict."""
    base = set()
    for key in ("name", "nickname", "surname", "partner", "pet", "company", "city"):
        val = profile.get(key)
        if val:
            base.add(val.strip())
    return {w for w in base if w}


def generate_wordlist(profile, min_len=4, max_variants_per_word=8, use_years=True):
    """
    Core generation pipeline:
        base words -> case variants -> leet variants -> + date tokens
                   -> + suffix/prefix mangling -> dedup -> filter by length
    """
    base_words = build_base_words(profile)
    date_toks = date_tokens(profile.get("dob", ""))

    mangled = set()

    # 1. Case + leet variants of each base word (and capitalized leet, e.g. "R1ya")
    for word in base_words:
        for cased in case_variants(word):
            mangled.add(cased)
        for leeted in leetspeak_variants(word, max_variants=max_variants_per_word):
            mangled.add(leeted)
            if leeted:
                mangled.add(leeted[0].upper() + leeted[1:])

    # 2. Pairwise combination of two base words (e.g. name + pet), in both
    #    raw-case and all-lowercase/capitalized forms
    word_list = list(base_words)
    for w1, w2 in itertools.permutations(word_list, 2):
        mangled.add(w1 + w2)
        mangled.add(w1.lower() + w2.lower())
        mangled.add(w1.capitalize() + w2.capitalize())

    # 3. Append date tokens to every mangled word
    combined = set(mangled)
    for word in mangled:
        for tok in date_toks:
            combined.add(word + tok)
            combined.add(tok + word)

    # 4. Suffix / prefix mangling
    final = set(combined)
    for word in combined:
        for suf in COMMON_SUFFIXES:
            final.add(word + suf)
        for pre in COMMON_PREFIXES:
            if pre:
                final.add(pre + word)

    # 5. Birth-year sweep for raw base words (common pattern: name + year)
    if use_years:
        for word in base_words:
            for year in DEFAULT_YEAR_RANGE:
                final.add(f"{word.lower()}{year}")

    # 6. Filter: drop anything shorter than min_len, keep ASCII printable only
    result = sorted(w for w in final if len(w) >= min_len and w.isascii())
    return result


# --------------------------------------------------------------------------
# CLI / interactive profile entry
# --------------------------------------------------------------------------

def prompt_profile():
    print("=== Target Profile Input (press Enter to skip a field) ===")
    fields = ["name", "nickname", "surname", "partner", "pet", "company", "city", "dob (DD-MM-YYYY)"]
    profile = {}
    for f in fields:
        key = f.split(" ")[0]
        val = input(f"{f}: ").strip()
        if val:
            profile[key] = val
    return profile


def load_profile(path):
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def main():
    parser = argparse.ArgumentParser(
        description="Generate a mangled, targeted wordlist from profile hints (CUPP-like)."
    )
    parser.add_argument("--config", "-c", help="Path to a JSON profile file")
    parser.add_argument("--interactive", "-i", action="store_true", help="Prompt for profile fields")
    parser.add_argument("--output", "-o", default="wordlist.txt", help="Output wordlist path")
    parser.add_argument("--min-len", type=int, default=4, help="Minimum password length to keep")
    parser.add_argument("--no-years", action="store_true", help="Skip the birth-year sweep (faster, smaller list)")
    args = parser.parse_args()

    if args.config:
        profile = load_profile(args.config)
    elif args.interactive:
        profile = prompt_profile()
    else:
        # Sensible demo default so the script runs with zero args
        profile = {
            "name": "Riya",
            "nickname": "Ri",
            "surname": "Sharma",
            "pet": "Tommy",
            "dob": "14-08-2003",
        }
        print("[*] No --config/--interactive given — using built-in demo profile.")
        print(f"[*] Demo profile: {profile}\n")

    if not profile:
        print("[!] Empty profile — nothing to generate from.", file=sys.stderr)
        sys.exit(1)

    wordlist = generate_wordlist(profile, min_len=args.min_len, use_years=not args.no_years)

    out_path = Path(args.output)
    out_path.write_text("\n".join(wordlist) + "\n", encoding="utf-8")

    print(f"[+] Base words used : {sorted(build_base_words(profile))}")
    print(f"[+] Total candidates: {len(wordlist)}")
    print(f"[+] Written to      : {out_path.resolve()}")


if __name__ == "__main__":
    main()
