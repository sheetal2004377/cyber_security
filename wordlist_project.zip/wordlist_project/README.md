# Exp 3 – Dictionary & Brute Force Attack
### Custom Wordlist Generator with Mangling Rules (CUPP-like)

## What this project does
1. **`wordlist_generator.py`** — builds a targeted wordlist from personal
   profile hints (name, nickname, pet, dob, etc.), the same idea as the
   real-world tool **CUPP** (Common User Passwords Profiler). It applies:
   - Leetspeak substitution (`a→4/@`, `e→3`, `i→1`, `o→0`, `s→5/$`, `t→7` ...)
   - Case variants (lower / UPPER / Capitalized / tOGGLE)
   - Word combinations (name+pet, name+partner, etc.)
   - Date-of-birth tokens (DDMM, MMDD, YYYY, YY, full DDMMYYYY)
   - Common suffixes/prefixes (`!`, `123`, `007`, `my`, `the`, ...)
   - A birth-year sweep (1980–2026) appended to each base word

2. **`make_sample_hashes.py`** — hashes a few chosen passwords (MD5, SHA-1,
   SHA-256) and writes them to `sample_hashes.txt`, so you have a known
   ground truth to test against.

3. **`crack_demo.py`** — the dictionary attack itself: hashes every word
   in `wordlist.txt` and checks it against each target hash, reporting
   which ones cracked, the recovered password, attempt count, and speed.

## How to run (step by step)

```bash
# 1. Generate a wordlist from the built-in demo profile (no args needed)
python3 wordlist_generator.py

# --- OR generate from your own profile ---
python3 wordlist_generator.py --interactive
# --- OR from a JSON file ---
python3 wordlist_generator.py --config profile.json -o wordlist.txt
```

`profile.json` example:
```json
{
  "name": "Rahul",
  "nickname": "Rahu",
  "surname": "Verma",
  "partner": "Anjali",
  "pet": "Bruno",
  "city": "Jaipur",
  "dob": "23-05-2002"
}
```

```bash
# 2. Create sample hashes to attack (edit SAMPLE_PASSWORDS inside this
#    file to passwords you expect your own wordlist to contain)
python3 make_sample_hashes.py

# 3. Run the dictionary attack
python3 crack_demo.py
```

Expected output: each hash is reported `[CRACKED]` with the recovered
plaintext, or `[FAILED]` if it wasn't derivable from the profile — both
outcomes are useful for your lab report (shows the tool works *and*
correctly reports its limits).

## Files
| File | Purpose |
|---|---|
| `wordlist_generator.py` | Main CUPP-like generator |
| `make_sample_hashes.py` | Creates `sample_hashes.txt` ground truth |
| `crack_demo.py` | Runs the dictionary attack, prints results |
| `wordlist.txt` | Generated output (created when you run the generator) |
| `sample_hashes.txt` | Generated output (created when you run make_sample_hashes) |

## Notes for your lab report
- This models a **dictionary/mangling-rule attack**, the realistic
  counterpart to brute force: instead of trying every possible string,
  it narrows the search space using OSINT-style personal information
  about the target, which is how most real-world password guessing
  (and tools like CUPP, John the Ripper's rule engine, or Hashcat rules)
  actually works in practice.
- You can extend `LEET_MAP`, `COMMON_SUFFIXES`, or `DEFAULT_YEAR_RANGE`
  in `wordlist_generator.py` to tune coverage vs. wordlist size.
- `crack_demo.py` reports attempts/sec — useful to discuss why real
  attackers use GPU-accelerated hashing (hashcat) for unsalted hashes,
  and why salting + slow hash functions (bcrypt/scrypt/argon2) defend
  against this exact attack.
- **Ethics/scope**: only use this against hashes/accounts you own or are
  explicitly authorized to test (e.g. this lab's own sample hashes).
