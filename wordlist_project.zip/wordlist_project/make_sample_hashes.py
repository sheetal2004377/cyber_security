#!/usr/bin/env python3
"""
Creates a small sample_hashes.txt file for the lab demo — a few
MD5 / SHA-1 / SHA-256 hashes of passwords that SHOULD be present in
wordlist.txt once you've generated it for the matching profile, plus
one "miss" hash that won't be cracked (to show the tool correctly
reports failures too).

This only uses passwords you choose yourself — it is not pulling any
real person's leaked credentials. Run this AFTER generating a wordlist
for a profile, and pick passwords that your generator will actually
produce (e.g. "Riya2003!", "riyatommy", "R1ya123").

Usage:
    python3 make_sample_hashes.py
"""

import hashlib

# Edit this list to passwords you expect your wordlist to contain.
SAMPLE_PASSWORDS = [
    "Riya2003!",   # should be produced by demo profile: name+dob+suffix
    "riyatommy",   # name + pet combo
    "R1ya123",     # leet + suffix
    "NotInList99", # deliberately NOT derivable -> should fail to crack
]


def hash_all(password: str):
    return {
        "md5": hashlib.md5(password.encode()).hexdigest(),
        "sha1": hashlib.sha1(password.encode()).hexdigest(),
        "sha256": hashlib.sha256(password.encode()).hexdigest(),
    }


def main():
    lines = []
    for pw in SAMPLE_PASSWORDS:
        h = hash_all(pw)
        # format: algorithm:hash   (so the cracker script knows which function to try)
        lines.append(f"md5:{h['md5']}")
        lines.append(f"sha1:{h['sha1']}")
        lines.append(f"sha256:{h['sha256']}")

    with open("sample_hashes.txt", "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")

    print(f"[+] Wrote {len(lines)} hashes (from {len(SAMPLE_PASSWORDS)} passwords) to sample_hashes.txt")
    print("[*] Ground-truth passwords used (for your lab report):")
    for pw in SAMPLE_PASSWORDS:
        print(f"    - {pw}")


if __name__ == "__main__":
    main()
